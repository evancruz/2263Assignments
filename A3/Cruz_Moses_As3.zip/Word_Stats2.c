#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "Word_Stats.h"


int main(int argc, char * * argv) {
  if(argc != 2){
    printf("Enter more args");
  }
  FILE *fp;
  char *a = argv[1];
  char str[500];
  char str2[500];
  char *s1 = str;
  char *s2 = str2;
  int totalSum = 0;
  int *sum = &totalSum;
  int numFound = 0;
  int *num = &numFound;
  double averageScore;
  double *avgScore = &averageScore;
  int numWords = 0;
  fp = fopen(a, "r");
  printf("Enter a review:\n");

  fgets(str, 500, stdin);
  for (int i = 0; i < 500; i++ ){
    if (str[i] == '\n' ) {
        str[i] = '\0';
        break;
    }
  }

  while(*s1 != '\0') {
    s1 = next_word(s1, s2);
    getWordStats(s2, fp, sum, num);
    if(*sum != 0){
      *avgScore += (double)*sum / (double)*num;
      numWords++;
    }
    *sum = 0;
    *num = 0;
    fseek(fp, 0, SEEK_SET);
  }
  *avgScore = *avgScore / numWords;
  printf("The review has an average value of %lf\n", averageScore);
  if(*avgScore > 2){
    printf("Positive Sentiment\n");
  }
  if(*avgScore < 2){
    printf("Negative Sentiment\n");
  }

  fclose(fp);
  return EXIT_SUCCESS;
}

void getWordStats(char *word, FILE *f, int *sum, int *num){
  char line[300];
  char *linePtr = line;
  char checkWord[100];
  char *checkW = checkWord;
  //get a line then go through each word in the line
  while(fgets(linePtr, 300, f)!= NULL){
    line[strlen(line)-1] = '\0';
    char *reviewScore = linePtr;
    linePtr++;
    while(*linePtr != '\0') {
      linePtr = next_word(linePtr, checkW);
      //do a string comparison of current word and word passed in
      if(checkForWord(checkW, word)== 1){
        *num = (*num) + 1;
        *sum += (*reviewScore) - 48;
      }
    }
    linePtr = line;
  }
}

char *next_word(char *linePtr, char *checkW){
  while(*linePtr != '\0' && *linePtr != ' '){
    *checkW = *linePtr;
    linePtr++;
    checkW++;
  }
  linePtr++;
  *checkW = '\0';
  return linePtr;
}

int checkForWord(char *checkWord, char *word){
  char *lowerCase = checkWord;
  while(*lowerCase){
    *lowerCase = tolower(*lowerCase);
    lowerCase++;
  }
  if(strcmp(checkWord, word) == 0) {
    return 1;
  }
  return 0;
}
