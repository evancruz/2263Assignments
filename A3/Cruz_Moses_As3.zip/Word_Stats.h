#ifndef Word_Stats_h
#define Word_Stats_h
#include <stdlib.h>
#include <stdio.h>

void getWordStats(char *word, FILE *f, int *sum, int *num);
char *next_word(char *linePtr, char *checkWord);
int checkForWord(char *line, char *word);

#endif
