#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
File Documentation: comment giving the author, date, and a brief
description of what functionality the code provides
/*  Moses Cruz
    January 12, 2018
    A program to evaluate whether a list of numbers given are sorted
*/
int main () {
  int initialInput;
  int counter;
  double previousInput;
  double nextInput;
  bool sorted = true;
  printf("Enter numbers to be read (>0): ");
  if (scanf("%d", &initialInput) != 1 || initialInput < 1 ){
      printf("%d is invalid: Enter an integer greater than 0\n", initialInput);
      return EXIT_FAILURE;
  } else {
      for(int i = initialInput; i > 0; i --) {
        if (scanf("%lf", &nextInput) == 1) {
          if(i < initialInput && nextInput < previousInput) {
            sorted = false;
          }
          previousInput = nextInput;
        } else {
          printf("Invalid: Please enter an integer\n");
          return EXIT_FAILURE;
        }
      }
  }
  printf(sorted ? "The numbers are sorted\n" : "The numbers are not sorted\n");
  return EXIT_SUCCESS;
}
