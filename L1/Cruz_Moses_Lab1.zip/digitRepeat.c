#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

/*  Moses Cruz
    January 12, 2018
    A program to change from decimal to given base between the ranges of 2 and X and checks to see if there are any repeating digits
*/
char numToChar (int num){
  if(num >= 0 && num <= 9) {
    return (char) (num + '0');
  } else {
    return (char) ((num -10) + 'A');
  }
}

int main () {
  int num;
  int numCopy;
  int base;
  int length = 0;
  char convertedNum[100];
  bool hasRepeat = false;

  printf("Enter integer: ");
  if(scanf("%d", &num) == 1 && (num < 999999 && num > 0)) {
    printf("Enter base: ");
    numCopy = num;
    if (scanf("%d", &base) == 1 && (base < 63 && base > 1)) {
      //printf("numcopy= %d\n", numCopy);
      for(int i = 0; i < 100 && numCopy > 0; i++) {
        convertedNum[i] = numToChar(numCopy % base);
        numCopy /= base;
        length++;
      }
      for(int i=0; i < length; i++) {
        for(int j = i+1; j < length; j++){
          if (convertedNum[i] == convertedNum [j]) {
            hasRepeat = true;
          }
        }
      }
      if (hasRepeat) {
        printf("%d base %d has repeated digits\n", num, base);
      } else {
        printf("%d base %d does not have repeated digits\n", num, base);
      }
    } else {
      printf("%d is an invalid input. Enter an integer between 2 and 62\n", base);
      return EXIT_FAILURE;
    }
  } else {
    printf("%d is an invalid input. Enter an integer between 0 and 999999\n", num);
    return EXIT_FAILURE;
  }
    return EXIT_SUCCESS;
}
