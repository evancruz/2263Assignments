#ifndef mystr_h
#define mystr_h
#include <stdlib.h>

char *next_word(char *str, char *word);
void remove_dup_blanks(char *str);

#endif mysth_h
