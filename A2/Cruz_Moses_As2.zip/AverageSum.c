#include <stdio.h>
#include <stdlib.h>

void avgSum(double a[], int n, double *avg, double *sum);
void printArr(double arr[], int length);

int main() {
  int length;
  double average = 0;
  double sum = 0;
  double *a = &average;
  double *s = &sum;

  scanf("%d", &length);
  double arr[length];
  for(int i = 0; i < length; i++){
    scanf("%lf", &arr[i]);
  }

  avgSum(arr, length, a, s);
  printf("Sum: %lf \nAverage: %lf\n", sum, average);
  return EXIT_SUCCESS;
}


void avgSum(double *arr, int n, double *avg, double *sum){
  *sum = 0.0;
  double *p;

  for(p = arr; p < arr+n; p++) {
    *sum += *p;
  }
  *avg = *sum/n;
}
