#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "token.h"

int main(){
  printf("Enter a sentence, por favor: ");
	char word[256];

	fgets(word, sizeof(word), stdin);

	char * ch = "\n, ";

	char ** token = stringTowords(word, ch);
	char ** ptr = token;
	while(*ptr != NULL){
		reverse(*ptr);
		ptr++;
	}

	ptr = token;
	while(*ptr != NULL){
		printf("%s ", *ptr);
		ptr++;
	}
	printf("\n");
	destroyTokens(token);
}
