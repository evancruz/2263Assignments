#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "token.h"

char ** stringTowords(char * str, char * sep){

	int wordCount = 0;

	char copy[256];
	strcpy(copy, str);

	char * word;
	word = strtok(str, sep);

	while(word != NULL){
		wordCount++;
		word = strtok(NULL, sep);
	}

	wordCount++; //to accomodate the null pointer
	char ** token = malloc(wordCount * sizeof(char*));
	int i = 0;
	word = strtok(copy, sep);

	while(word != NULL){
		token[i] = malloc(strlen(word)*sizeof(char));
		strcpy(token[i], word);
		i++;
		word = strtok(NULL, sep);
	}
	return token;
}

void reverse(char *s){
	int i = strlen(s);

	char *p1 = s;
	char *p2 = s + strlen(s) - 1;

	while(p1<p2) {
		char tmp = *p1;
		*p1++ = *p2;
		*p2-- = tmp;
	}
}

void destroyTokens(char ** tokenArray){

	char ** ptr = tokenArray;
	while(*ptr != NULL){
		free(*ptr);
		ptr++;
	}

	free(tokenArray);
}
