#ifndef token_h
#define token_h
#include <stdlib.h>
#include <stdio.h>

char ** stringTowords(char * str, char * sep);
void reverse(char *s);
void destroyTokens(char ** tokenArray);

#endif
