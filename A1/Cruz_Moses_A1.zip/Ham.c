#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool isHamiltonian(int arr[], int length);
bool checkValidPath(int arr[], int length, bool status);

int main() {
  int offsetInput;
  int edgesInput;
  int pathArray[100];
  int count = 0;
  int path;
  bool valid = true;
  bool validPath = true;
  bool hamil = false;

  scanf("%d %d", &offsetInput, &edgesInput);
  //printf("off = %d edge = %d", offsetInput, edgesInput);

  int hamiltonian[100];
  for(int i = 0; i < offsetInput; i++){
    hamiltonian[i] = 0;
  }
  int offset[offsetInput];
  int edges[edgesInput];
  for(int i = 0; i <= offsetInput; i++) {
    scanf("%d", &offset[i]);
  }
  for(int i = 0; i < edgesInput; i++) {
    scanf("%d", &edges[i]);
  }

  int p;
  int c;
  scanf("%d", &p);
  pathArray[count] = p;
  count++;
  while(scanf("%d", &c) == 1 && valid) {
    pathArray[count] = c;
    count++;
    for(int i = offset[p]; i < offset[p+1]; i++) {
      if(edges[i] == c) {
        valid = true;
        i = p+10;

      } else {
        valid = false;
      }
    }

    if(!valid){
      validPath = false;
    }
    hamiltonian[p]++;
    p = c;

  }
  hamiltonian[c]++;
  hamil = isHamiltonian(hamiltonian, offsetInput);
  validPath = checkValidPath(hamiltonian, offsetInput, validPath);

  for(int i = 0; i < count; i++) {
    printf("%d ", pathArray[i]);
  }

  printf(validPath ? "is a path\n" : "is not a path\n");
  printf(hamil ? "and is a Hamiltonian path\n" : "and is NOT a Hamiltonian path\n");
  return EXIT_SUCCESS;
}

bool isHamiltonian(int arr[], int length) {
  bool success = true;
  for(int i = 0; i < length; i++) {
    if(arr[i] != 1){
      success = false;
    }
  }
  return success;
}
bool checkValidPath(int arr[], int length, bool status) {
  for(int i = 0; i < length; i++) {
    if(arr[i] > 1){
      status = false;
    }
  }
  return status;
}
